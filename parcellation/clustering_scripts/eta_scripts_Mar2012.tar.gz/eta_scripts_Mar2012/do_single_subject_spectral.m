
function assignments=do_single_subject_spectral(etaSq, k)

%Written by: Clare Kelly, Senior Underpants Gnome, 1st June 2011
%---------------------------------------------------------------

global_options
params1  = 'mcut_all';
params2 = 'kmeans';

assignments=zeros(size(etaSq,1), k-1);

for solution=2:k
    display(['k=' num2str(solution)])
    
    assignments(:, solution-1)= transpose(cluster_spectral_general(etaSq, solution, params1, params2));
    
end
